from flask import Flask, render_template  # Import Flask to allow us to create our app
app = Flask(__name__)    # Create a new instance of the Flask class called "app"

@app.route('/')         
def main():
    return render_template("checker.html", rows=8, columns=8)  

@app.route('/<int:y>')         
def oneDimension(y):
    return render_template("checker.html", rows=8, columns=y) 

@app.route('/<int:x>/<int:y>')         
def twoDimensions(x, y):
    return render_template("checker.html", rows=x, columns=y) 

if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)