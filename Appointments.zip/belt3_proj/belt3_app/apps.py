from django.apps import AppConfig


class Belt3AppConfig(AppConfig):
    name = 'belt3_app'
